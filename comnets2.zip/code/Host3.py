#!/usr/bin/python
#Topology for Assignment 5 Comnetii ECE423/544
#Author: Sanyam Jain
from socket import socket, AF_INET, SOCK_DGRAM
import MulticastPacket as p

class Host3:

    def sendReceive(self):
        currentNode=103
        s = socket(AF_INET, SOCK_DGRAM)
        s.bind(('localhost', 1026))
        try:
            while(True):
                data, addr = s.recvfrom(1024)
                pkttype, pktlen, ndest, rdst, dest1, dest2, dest3, src, seq = p.read_header_datapacket(data)
                print(p.read_data_datapacket(data).decode('utf-8') + " from ",src)
                if(currentNode==dest1):
                    ackPacket=p.create_dataack(5,1,currentNode,202)
                    s.sendto(ackPacket,addr)

        except KeyboardInterrupt:
            s.close()
            print('interrupted!')

def run():
    h2 = Host3()
    h2.sendReceive()

if __name__ == '__main__':
    run()
